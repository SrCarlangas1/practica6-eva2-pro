/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica.pkg6;

import java.util.Scanner;

/**
 *
 * @author infor12
 */
public class Empleado {
    
    protected String nombre;
    protected String apellidos1;
    protected String apellido2;
    protected String nif;
    protected int edad;
    protected int salario;

    public Empleado(String nombre, String apellidos1, String apellido2, String nif, int edad, int salario) {
        this.nombre = nombre;
        this.apellidos1 = apellidos1;
        this.apellido2 = apellido2;
        this.nif = nif;
        this.edad = edad;
        this.salario = salario;
    }

    public Empleado() {
    }

    
/*------------Los Geters---------------------*/
/*----------------------------------------------------------------------------*/
    public String getNombre() {
        return nombre;
    }

    public String getApellidos1() {
        return apellidos1;
    }

    public String getApellido2() {
        return apellido2;
    }

    public String getNif() {
        return nif;
    }

    public int getEdad() {
        return edad;
    }

    public int getSalario() {
        return salario;
    }
/*----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/
    
/*------------Los Seters---------------------*/
/*----------------------------------------------------------------------------*/
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setApellidos1(String apellidos1) {
        this.apellidos1 = apellidos1;
    }

    public void setApellido2(String apellido2) {
        this.apellido2 = apellido2;
    }

    public void setNif(String nif) {
        this.nif = nif;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public void setSalario(int salario) {
        this.salario = salario;
    }
/*----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/
    
    
    
/*---------Pedir Alta empleado---------*/
    
    public void pedirAlta(){
        
        Scanner lector=new Scanner(System.in);
        System.out.println("======================");
        System.out.println("ALTA EMPLEADO... ");
        System.out.println("----------------------");
        System.out.println("¿Introduce el Nombre?");
        this.setNombre(lector.nextLine());      
        System.out.println("¿Introduce el Primer apellido?");
        this.setApellidos1(lector.nextLine());
        System.out.println("¿Introduce el Segundo apellido?");
        this.setApellido2(lector.nextLine());        
        System.out.println("¿Introduce el NIF?");
        this.setNif(lector.nextLine());  
        System.out.println("¿Introduce el Edad?");
        this.setEdad(lector.nextInt());
        System.out.println("¿Introduce el Salario?");
        this.setSalario(lector.nextInt());
    
    }
    
}

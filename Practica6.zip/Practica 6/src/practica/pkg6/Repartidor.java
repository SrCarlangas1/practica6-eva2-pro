/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica.pkg6;

import java.util.Scanner;

/**
 *
 * @author infor12
 */
public class Repartidor extends Empleado{
    
        private String zona;

    public Repartidor() {
        super();
    }            
                     
    public Repartidor(String zona, String nombre, String apellidos1, String apellido2, String nif, int edad, int salario) {
        super(nombre, apellidos1, apellido2, nif, edad, salario);
        this.zona = zona;
    }
    
/*------------Los Geters---------------------*/
/*----------------------------------------------------------------------------*/
    public String getZona() {
        return zona;
    }

/*----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/
    
/*------------Los Seters---------------------*/
/*----------------------------------------------------------------------------*/
    public void setZona(String zona) {
        this.zona = zona;
    }

/*----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/
    
/*---------Pedir Alta Repartidor---------*/
    @Override
    public void pedirAlta(){
    Scanner lector=new Scanner(System.in);
    super.pedirAlta();
    System.out.println("¿Introduce la zona?");
    this.setZona(lector.nextLine());
    }      
}

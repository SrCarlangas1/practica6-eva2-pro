/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica.pkg6;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author infor12
 */
public class Practica6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
                int a =0;
        System.out.println("Que deseas hacer");
        System.out.println("1.Gestión administrativa");
        System.out.println("2.Utilidades usuario");


        Scanner sc = new Scanner(System.in);
        System.out.println("Elige una opción;");
        a = sc.nextInt();
            
            switch (a) {
                case 1:
                    System.out.println("1.Gestión administrativa");
                            int b =0;
                            System.out.println("Que deseas hacer");
                            System.out.println("1.Alta Empleado");
                            System.out.println("2.Alta Comercial");
                            System.out.println("3.Alta Repartidor");
                            System.out.println("4.Mostar Empleados");
                                    
                            System.out.println("Elige una opción;");
                            b = sc.nextInt();
                            ArrayList<Empleado> listaEmpleado = new ArrayList<>();
                                switch (b){
                                    case 1:
                                        System.out.println("1.Alta Empleado");
                                        Empleado usuario= new Empleado();
                                        usuario.pedirAlta();
                                        listaEmpleado.add(usuario);
                                        
                                        break;
                                    case 2:
                                        System.out.println("2.Alta Comercial");
                                        Comercial comercial= new Comercial();
                                        comercial.pedirAlta();
                                        listaEmpleado.add(comercial);
                                        
                                         break;
                                    case 3:
                                        System.out.println("3.Alta Repartidor");
                                        Repartidor repartidor= new Repartidor();
                                        repartidor.pedirAlta();
                                        listaEmpleado.add(repartidor);
                                        
                                        break;
                                    case 4:
                                        System.out.println("4.Mostar Empleados");
                                }
                        }               
    }
}

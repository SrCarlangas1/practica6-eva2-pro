/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica.pkg6;

import java.util.Scanner;

/**
 *
 * @author infor12
 */
public class Comercial extends Empleado{
    
        private double comision;

    public Comercial() {
        super();
    }

    public Comercial(double comision, String nombre, String apellidos1, String apellido2, String nif, int edad, int salario) {
        super(nombre, apellidos1, apellido2, nif, edad, salario);
        this.comision = comision;
    }
    
 
/*------------Los Geters---------------------*/
/*----------------------------------------------------------------------------*/
    public double getComision() {
        return comision;
    }

/*----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/
    
/*------------Los Seters---------------------*/
/*----------------------------------------------------------------------------*/
    public void setComision(double comision) {
        this.comision = comision;
    }

/*----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/   
    
/*---------Pedir Alta Comercial---------*/
    @Override
    public void pedirAlta(){
    Scanner lector=new Scanner(System.in);
    super.pedirAlta();
    System.out.println("¿Introduce la comision?");
    this.setComision(lector.nextInt());
    }  
    
}
